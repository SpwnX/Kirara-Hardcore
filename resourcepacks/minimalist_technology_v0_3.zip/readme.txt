﻿WARNING : THIS PACK IS A BETA RELEASE and not supposed to be massively redistributed. There's a lot of IC2's original textures in here that doesn't belong to anyone but their original creators, so my license doesn't apply to them. Thank you for your understanding.

Pyrolusite's Minimalist Technology

/*------------*\
  DESCRIPTION 
\*------------*/

This is my alternative to GT6 and IC2 Experimental textures.
Initially, I couldn't stand GT5's textures when its alpha came out, so I decided to make my own resource pack for GT5. Since then, I decided to do it with IC2 Experimental as well, but in separate packs (Pyrolusite's GregTech Alternate Textures - PGTAT - and Pyrolusite's IC2 Alternate Textures - PICAT.) Starting to rework both of them since GT6, I decided to merge them into a single resource pack.

My textures are inspired from the original ones, while adding my own touch. I tend to use a limited color palette and stick with it for a lot of my work, hence why I consider it "minimalist".

This resource pack is intended to be modular, which means you can add it to your resource pack list ingame - make sure it's placed above your main resource pack if you're using one modifying other textures of the mod - and it will run without any problems.

/*-----------*\
  LEGAL STUFF  
\*-----------*/

This resource pack has been created by Pyrolusite (@pyrolusite76), and can be found here : http://forum.industrial-craft.net/index.php?page=Thread&threadID=10612

This Resource Pack is under a Creative Commons License - Attribution, Non Commercial, Share Alike 4.0 International - which means you can do whatever you want with it as long as you do not make money from it, credit me when using my work for whatever purpose and use the same license.
More info here : http://creativecommons.org/licenses/by-nc-sa/4.0/deed.en
