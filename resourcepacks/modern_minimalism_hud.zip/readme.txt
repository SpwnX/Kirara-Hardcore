﻿Pyrolusite's Modern Minimalism

/*------------*\
  DESCRIPTION 
\*------------*/

What is this ?
This Resource Pack was initially created for my personal use, in order to have a more minimalistic and simpler HUD. It evolved into something inspired from the "TukMC" hud mod, originally created by Vazkii.

Why is it modular ?
Since Minecraft 1.7, you can enable more than one texture pack at the same time and change their order, the first one being loaded last. This resource pack does not alter items (except the armor placeholders on the inventory screen) nor blocks, allowing you to use it alongside another one without problems. Needless to say, it also works well by itself.

If you are using Minecraft 1.6.4, you might want to merge this resource pack with the one you like to get the same results.

Why is it minimalist ?
It is because of the limited palette I used for this resource pack. Though, it has somewhat SF-esque influences.

/*------------*\
  INSTALLATION  
\*------------*/

Put this .zip archive into your "resourcepack" folder. That's it.

/*-----------*\
  LEGAL STUFF  
\*-----------*/

This resource pack has been created by Pyrolusite (@pyrolusite76), and can be found here : 
http://www.minecraftforum.net/forums/mapping-and-modding/resource-packs/1245953

This Resource Pack is under a Creative Commons License - Attribution, Non Commercial, Share Alike 4.0 International - which means you can do whatever you want with it as long as you do not make money from it, credit me when using my work for whatever purpose and use the same license.
More info here : http://creativecommons.org/licenses/by-nc-sa/4.0/deed.en
